#ifndef OLED_UI_H
#define OLED_UI_H

#include "RTClib.h"
#include "globals.h"

// ─────────────────────────────────────────────────────────────────────────────
// INIT
// ─────────────────────────────────────────────────────────────────────────────
void oled_init(void);

// ─────────────────────────────────────────────────────────────────────────────
// HOME SCREENS
// ─────────────────────────────────────────────────────────────────────────────
void oled_show_home_incubator(const DateTime& now,
                               int     day,
                               int     daysLeft,
                               float   temp,
                               float   hum,
                               float   tempSP,
                               float   humSP,
                               bool    isAuto,
                               bool    heaterOn,
                               bool    humidifierOn,
                               bool    fanOn,
                               bool    turnerOn,
                               bool    wifiOk,
                               const char* milestoneLabel);

void oled_show_home_climate(const DateTime& now,
                             float  temp,
                             float  hum,
                             float  tempSP,
                             float  humSP,
                             bool   isAuto,
                             bool   heaterOn,
                             bool   coolerOn,
                             bool   humidifierOn,
                             bool   wifiOk,
                             const char* phaseLabel);

// ─────────────────────────────────────────────────────────────────────────────
// FAULT SCREEN
// ─────────────────────────────────────────────────────────────────────────────
void oled_show_fault_screen(float currentTemp);

// ─────────────────────────────────────────────────────────────────────────────
// MENUS
// ─────────────────────────────────────────────────────────────────────────────
void oled_show_menu(int selected);
void oled_show_controller_mode(int selected, ProfileType activeProfile);
void oled_show_set_environment(int selected, ProfileType profile);
void oled_show_settings_menu(int selected);
void oled_show_mode_menu(int selected);
void oled_show_manual_control(int selected, bool heaterOn, bool coolerOn, ProfileType profile);
void oled_show_climate_mode_menu(int selected, ClimateModeType active);

// ─────────────────────────────────────────────────────────────────────────────
// ENVIRONMENT EDIT SCREENS
// ─────────────────────────────────────────────────────────────────────────────
void oled_show_temperature(float current, float setpoint);
void oled_show_humidity(float current, float setpoint);
void oled_show_hysteresis_menu(int selected, float tempHyst, float humHyst);

// ─────────────────────────────────────────────────────────────────────────────
// EGG INCUBATOR SCREENS
// ─────────────────────────────────────────────────────────────────────────────
void oled_show_egg_type(int selected);
void oled_show_incubation_day_set(int day, int month, int year);
void oled_show_turner_settings(int selected,
                                uint16_t intervalMin,
                                uint16_t durationSec);
void oled_show_fan_settings(int selected,
                             uint16_t intervalMin,
                             uint16_t durationSec);

// ─────────────────────────────────────────────────────────────────────────────
// CLIMATE CHAMBER SCREENS
// ─────────────────────────────────────────────────────────────────────────────
void oled_show_climate_schedule(int selected,
                                 uint8_t startHour,
                                 uint8_t endHour);
void oled_show_climate_cyclic(int selected,
                               uint32_t heatMin,
                               uint32_t coolMin);
void oled_show_climate_ramp(int selected,
                             uint8_t stepCount,
                             const RampStep_t* steps,
                             uint8_t activeStep);

// ─────────────────────────────────────────────────────────────────────────────
// SETTINGS SCREENS
// ─────────────────────────────────────────────────────────────────────────────
void oled_show_device_info(const char* deviceId,
                            const char* fwVersion,
                            const char* ipAddr,
                            const char* profileName,
                            uint32_t    uptimeSec);

void oled_show_factory_reset_confirm(void);

#endif // OLED_UI_H
